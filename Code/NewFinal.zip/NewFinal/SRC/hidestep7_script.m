%hidestep7_script.m
%   This script hides the objects for step 7, final image threshold

% hide objects
set(handles.finalthreshold_slider,'Visible','off');
set(handles.finalthreshold_edit,'Visible','off');
set(handles.undo7_pushbutton,'Visible','off');
set(handles.continue7_pushbutton,'Visible','off');
set(handles.thresholdedit_text,'Visible','off');