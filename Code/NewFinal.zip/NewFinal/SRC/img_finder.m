function [wiltdata_array] = img_finder(img_directory, result_directory)
    wiltdata_array = [];
    img_array = img_array_func(img_directory);
    
    if ~isempty(img_array)
        filename = string(getfilename(img_directory));
        w = wiltdata(filename, img_array, result_directory);        
        wiltdata_array = [wiltdata_array, w];
    end 
    
    files = dir(img_directory);
    dirFlags = [files.isdir];
    subFolders = files(dirFlags);
    subFolders = subFolders(3:end);
    
    if ~isempty(subFolders)
        for k = 1 : length(subFolders)
            img_array = img_array_func(strcat(img_directory, '\', subFolders(k).name));
            filename = strcat('\', subFolders(k).name);
            w = wiltdata(filename, img_array, result_directory);
            wiltdata_array = [wiltdata_array, w];
        end
    end
end