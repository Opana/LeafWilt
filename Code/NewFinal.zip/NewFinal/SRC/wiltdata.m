% constructor for wiltdata objects
classdef wiltdata < matlab.mixin.SetGet
    properties
        file_directory
        dest_directory
        img_array
        filename
        rect_array
        initialframe_num
        finalframe_num
        initialthreshold
        finalthreshold
        sharpenradius
        rgb_channel
        invert_TF
        stalk_x
        stalk_y
        img_cropwidth
        img_cropheight
        angle_data
    end
    methods
        function w = wiltdata(filename, img_array, dest_directory)
            set(w, 'filename', filename);
            set(w, 'img_array', img_array);
            set(w, 'dest_directory', dest_directory);
        end
        function [wiltcount, wiltdata] = wilt_array_selector(wiltcount, wiltdata_array)
            wiltcount = wiltcount + 1;
            wiltdata = wiltdata_array(wiltcount);
        end
        function w = wiltdata_compiler(rect_array, initialframe_num, finalframe_num, initialthreshold, finalthreshold, sharpenradius, rgb_channel, invert_TF, stalk_x, stalk_y, img_cropwidth, img_cropheight)
            w.rect_array = rect_array;
            w.initialframe_num = initialframe_num;
            w.finalframe_num = finalframe_num;
            w.initialthreshold = initialthreshold;
            w.finalthreshold = finalthreshold;
            w.sharpenradius = sharpenradius;
            w.rgb_channel = rgb_channel;
            w.invert_TF = invert_TF;
            w.stalk_x = stalk_x;
            w.stalk_y = stalk_y;
            w.img_cropwidth = img_cropwidth;
            w.img_cropheight = img_cropheight;
        end
    end
end