%hidestep6_script.m
%   This script hides the objects for step 6, final image selection

% hide objects from select-final-frame step
set(handles.finalframe_slider,'Visible','off');
set(handles.undo6_pushbutton,'Visible','off');
set(handles.continue6_pushbutton,'Visible','off');