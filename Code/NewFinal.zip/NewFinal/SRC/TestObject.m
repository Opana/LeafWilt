classdef TestObject
    %TESTOBJECT Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        Name
        Gender
        Address
        Party_status
        Finger_num
    end
    
    methods
        
    end
end

