% hidestep9_script
%   This script hides all objects from the post-analysis step

% hide objects
% show objects
set(handles.exportcsv_pushbutton,'Visible','off');
set(handles.nextplant_pushbutton,'Visible','off');