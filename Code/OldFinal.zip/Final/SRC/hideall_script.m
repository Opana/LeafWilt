% hideall_script.m
% This script hides all objects

hidestep2_script;
hidestep3_script;
hidestep4_script;
hidestep5_script;
hidestep6_script;
hidestep7_script;
hidestep8_script;
hidestep9_script;
hidewelcome_script;

