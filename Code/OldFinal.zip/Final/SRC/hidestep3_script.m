%hidestep3_script.m
%   This script hides the objects from step 3

% hide objects from the crop-frame step
set(handles.continue3_pushbutton,'Visible','off');
set(handles.undo3_pushbutton,'Visible','off');
set(handles.cropwidth_slider,'Visible','off');
set(handles.cropheight_slider,'Visible','off');

