%hidestep4_script.m
%   This script hides the objects from step 4

% hide objects from the select leaves step
set(handles.continue4_pushbutton,'Visible','off');
set(handles.undo4_pushbutton,'Visible','off');


